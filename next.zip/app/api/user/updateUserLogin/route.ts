// import { PrismaClient } from "@prisma/client";
// export async function POST(req: NextRequest) {
  export async function POST() {
  // const body = await req.json();
  // const prisma = new PrismaClient();
  // const main = async () => {
    
  // };
  // const res = await prismaErrorCatch(prisma, main);
  return Response.json({});
}
