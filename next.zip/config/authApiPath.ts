// 需要验证token的接口
export default ['/user/queryChatList', '/user/queryFilterList', '/user/queryUserBasis', '/user/updateUserLogin', '/user/updateUserBasis', '/user/updateChatList']