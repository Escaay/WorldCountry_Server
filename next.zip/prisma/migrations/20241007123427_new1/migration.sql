/*
  Warnings:

  - You are about to drop the column `body` on the `chat_list` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `chat_list` DROP COLUMN `body`;
