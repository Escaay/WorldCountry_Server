-- AlterTable
ALTER TABLE `user_basis` MODIFY `avatarURL` TEXT NOT NULL;
