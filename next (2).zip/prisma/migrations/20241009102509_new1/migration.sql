-- AlterTable
ALTER TABLE `user_basis` ADD COLUMN `filterConds` JSON NULL;
