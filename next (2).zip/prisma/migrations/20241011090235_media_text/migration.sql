-- AlterTable
ALTER TABLE `user_basis` MODIFY `avatarURL` MEDIUMTEXT NOT NULL;
