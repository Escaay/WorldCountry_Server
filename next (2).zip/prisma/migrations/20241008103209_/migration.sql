-- AlterTable
ALTER TABLE `user_basis` MODIFY `avatarURL` VARCHAR(191) NOT NULL DEFAULT '';
